<template>
	<v-img></v-img>
</template>
<script>
	import vImg from './components/img.vue';
	export default {
		components:{
			vImg
		}
	}
</script>

<style>
	/*每个页面公共css */
</style>
